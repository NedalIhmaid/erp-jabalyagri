<?php

namespace App\Filament\Resources\ProductFamilyResource\Pages;

use App\Filament\Resources\ProductFamilyResource;
use Filament\Actions\EditAction;
use Filament\Resources\Pages\ViewRecord;

class ViewProductFamily extends ViewRecord
{
    protected static string $resource = ProductFamilyResource::class;
    protected function getHeaderActions(): array { return [EditAction::make()]; }
}
